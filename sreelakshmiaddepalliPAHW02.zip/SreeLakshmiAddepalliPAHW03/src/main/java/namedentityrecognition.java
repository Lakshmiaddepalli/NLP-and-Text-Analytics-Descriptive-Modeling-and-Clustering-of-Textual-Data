package main.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;

import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.NamedEntityTagAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;

public class namedentityrecognition {

	static LinkedHashMap <String,LinkedHashMap<String,Integer>> nervalues=new <String,LinkedHashMap<String,Integer>>LinkedHashMap();


	public static void namedentityrecognition(String text) {
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize,ssplit,pos,lemma,ner");
		props.setProperty("ner.applyFineGrained", "false");
		CoreDocument doc = new CoreDocument(text);
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
		pipeline.annotate(doc);
		for (CoreEntityMention em : doc.entityMentions()) {
			String category = em.entityType();
			String word = em.text().replaceAll("[^A-Za-z0-9 .\r\n-]+", "").toLowerCase();
			//   System.out.println("\tdetected entity: \t"+em.text().replaceAll("[^A-Za-z0-9 .\r\n-]+", "").toLowerCase()+"\t"+em.entityType());
			if(nervalues.containsKey(category)) {
				if(nervalues.get(category).containsKey(word)) {
					nervalues.get(category).put(word, nervalues.get(category).get(word) + 1);
				}
				else {
					nervalues.get(category).put(word, 1);
				}
			}
			else{
				LinkedHashMap<String,Integer> temp=new LinkedHashMap<String,Integer>();
				temp.put(word,1);
				nervalues.put(category,temp);
			}
			System.out.println(word+":"+category);
			System.out.println(nervalues.toString());
		}
	}

	public static File print_ner_tags(LinkedHashMap <String,LinkedHashMap<String,Integer>> nerstring,int threshold) throws IOException {
		BufferedWriter writer = null;
		File file = new File("src/resources/namedentityrecognition/namedentityrecognisedwords.txt");
		file.createNewFile();
		writer = new BufferedWriter(new FileWriter(file));
		for (Entry<String,LinkedHashMap<String,Integer>>  entry1 : nerstring.entrySet()) {
			for(Entry<String,Integer> entry2 : entry1.getValue().entrySet()) {
				if(entry2.getValue()>threshold) {
					writer.write(entry2.getKey().toString());
					writer.newLine();
				}
			}
		}
		writer.close();
		return file;		
	}
}