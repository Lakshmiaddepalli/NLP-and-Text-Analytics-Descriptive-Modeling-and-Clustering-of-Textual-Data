package main.java;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.awt.geom.AffineTransform;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.plot.CrosshairState;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleEdge;


public class visualise extends JFrame {

	public static HashMap<Integer, Tuple> reduceddimesions = null;
	public visualise(String title) {  
		super(title);  
		// Create dataset  
		XYDataset dataset = createDataset();  
		XYDotRenderer renderer1 = new XYDotRendererTZ();
		// Create chart  
		JFreeChart chart = ChartFactory.createScatterPlot(  
				"Actual Clusters VS Predicted Clusters weight comparison chart",   
				"X-Axis", "Y-Axis", dataset, PlotOrientation.VERTICAL, true, true, false);  

		//Changes background color  
		XYPlot plot = (XYPlot)chart.getPlot();  
		plot.setBackgroundPaint(new Color(255,228,196));  

		// Create Panel  
		ChartPanel panel = new ChartPanel(chart);  
		setContentPane(panel);  
	}

	private XYDataset createDataset() {  
		XYSeriesCollection dataset = new XYSeriesCollection();

		for(Entry<String, ArrayList<Integer>> entry1: termdocumentmatrix.actualclass.entrySet()) {
			XYSeries series1 = new XYSeries("Actual_" + entry1.getKey());  
			for(Integer y: entry1.getValue()) {
				double xpoint = reduceddimesions.get(y).getX();
				double ypoint = reduceddimesions.get(y).getY();
				series1.add(xpoint,ypoint);
			}
			dataset.addSeries(series1);  
		}

		for(Entry<String, ArrayList<Integer>> entry1: kmeans.predictedclass.entrySet()) {
			XYSeries series1 = new XYSeries("Predicted_" + entry1.getKey());  
			for(Integer y: entry1.getValue()) {
				double xpoint = reduceddimesions.get(y).getX();
				double ypoint = reduceddimesions.get(y).getY();
				series1.add(xpoint,ypoint);
			}
			dataset.addSeries(series1);  
		}

		return dataset;  
	}


	public static void data(HashMap<Integer, Tuple> reduced_data) {
		// TODO Auto-generated method stub
		reduceddimesions = reduced_data;
		SwingUtilities.invokeLater(() -> {  
			visualise example = new visualise("Document Clustering Visualisation");  
			example.setSize(800, 400);  
			example.setLocationRelativeTo(null);  
			example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);  
			example.setVisible(true);  
		}); 
	}

}

class XYDotRendererTZ extends XYDotRenderer
{
	public void drawItem(Graphics2D g2,
			Rectangle2D dataArea,
			ChartRenderingInfo info,
			XYPlot plot,
			ValueAxis domainAxis,
			ValueAxis rangeAxis,
			XYDataset dataset,
			int series,
			int item,
			CrosshairState crosshairInfo,
			int pass)
	{
		// setup for collecting optional entity info...
		Shape entityArea = null;
		EntityCollection entities = null;
		if (info != null) {
			entities = info.getEntityCollection();
		}

		Paint paint = getItemPaint(series, item);
		Stroke seriesStroke = getItemStroke(series, item);
		g2.setPaint(paint);
		g2.setStroke(seriesStroke);

		// get the data point...
		Number x1n = dataset.getXValue(series, item);
		Number y1n = dataset.getYValue(series, item);
		if (y1n == null) {
			return;
		}

		double x1 = x1n.doubleValue();
		double y1 = y1n.doubleValue();
		final RectangleEdge xAxisLocation = plot.getDomainAxisEdge();
		final RectangleEdge yAxisLocation = plot.getRangeAxisEdge();
		double transX1 = domainAxis.valueToJava2D(x1, dataArea,
				xAxisLocation);
		double transY1 = rangeAxis.valueToJava2D(y1, dataArea,
				yAxisLocation);

		//Shape shape = getItemShape(series, item);
		Shape shape = new Ellipse2D.Double(x1, y1, 20.0, 20.0);
		PlotOrientation orientation = plot.getOrientation();
	/*	if (orientation == PlotOrientation.HORIZONTAL) {
			shape = createTransformedShape(shape, transY1, transX1);
		}
		else if (orientation == PlotOrientation.VERTICAL) {
			shape = createTransformedShape(shape, transX1, transY1);
		}*/
		if (shape.intersects(dataArea)) {
			g2.draw(shape);
			g2.fill(shape);
		}
		entityArea = shape;
	}
}
