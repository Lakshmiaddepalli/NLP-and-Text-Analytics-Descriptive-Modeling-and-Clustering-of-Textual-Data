package main.java;

import java.util.ArrayList;

public class simlaritydistance {
	
	public static double computeCosineSimilarity(ArrayList<Double> document,ArrayList<Double> centroid) {

		double dotProduct = 0.0;
		double normA = 0.0;
		double normB = 0.0;
		double[] documentarray = new double[document.size()];
		double[] centroidarray = new double[centroid.size()];
		for(int i = 0;i < document.size();i++) {
			documentarray[i]=document.get(i);
			centroidarray[i]=centroid.get(i);
		}

		for (int i = 0; i < document.toArray().length; i++) {
			dotProduct += documentarray[i] * centroidarray[i];
			normA += Math.pow(documentarray[i], 2);
			normB += Math.pow(centroidarray[i], 2);
		}   
		return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));

	}

	public static double computeEuclidianSimilarity(ArrayList<Double> document,ArrayList<Double> centroid) {
		double totalvalue = 0.0;

		double[] documentarray = new double[document.size()];
		double[] centroidarray = new double[centroid.size()];
		for(int i = 0;i < document.size();i++) {
			documentarray[i]=document.get(i);
			centroidarray[i]=centroid.get(i);
		}

		for (int i = 0; i < document.toArray().length; i++) {
			totalvalue += Math.pow(documentarray[i] - centroidarray[i],2);
		}   
		return Math.sqrt(totalvalue);

	}


}
