package main.java;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.DocumentPreprocessor;

public class ngram {

	static Map<String, Integer> dictionary = new HashMap<String, Integer>();

	public static ArrayList<String> ngrams(int n, ArrayList<String> text) {
		ArrayList<String> ngrams = new ArrayList<String>();
		//      DocumentPreprocessor dp = new DocumentPreprocessor(text);
		//      for (List<HasWord> sentence : dp) {
		//    	  System.out.println(sentence.toString());
		//    	  String[] words = preprocess.Lemmitisation(sentence.toString(),true).toString().split(" ");
		String[] words = new String[text.size()];
		words = text.toArray(words);
		for (int i = 0; i < words.length - n + 1; i++)
			ngrams.add(join(words, i, i+n));
		//    }

		return ngrams;
	}

	public static String join(String[] words, int start, int end) {
		StringBuilder sb = new StringBuilder();
		for (int i = start; i < end; i++)
			sb.append((i > start ? " " : "") + words[i]);
		return sb.toString();
	}

	public static void counter(List<String> ngrams) {
		// TODO Auto-generated method stub
		for(String s:ngrams) {
			if (dictionary.containsKey(s)) {
				dictionary.put(s, dictionary.get(s) + 1);
			}else {
				dictionary.put(s,1);
			}
		}
	}

	public static File printtofile(int threshold,int frequency) throws IOException {
		BufferedWriter writer = null;
		File file = new File("src/resources/ngrams_frequency/" + frequency + "gram.txt");
		//	System.out.print(System. getProperty("user.dir"));
		file.createNewFile();
		writer = new BufferedWriter(new FileWriter(file));
		for (Entry<String, Integer> entry : dictionary.entrySet()) {
			if(entry.getValue()>threshold) {
				System.out.println("Key: " + entry.getKey() + " Count: " + entry.getValue());
				writer.write(entry.getKey());
				writer.newLine();
			}
		}
		writer.close();
		return file;
	}

	public static File mergefile(File file2, File nerfile) throws IOException {
		BufferedWriter writer = null;
		File file = new File("src/resources/final_frequent_words/frequent_words.txt");
		System.out.print(System. getProperty("user.dir"));
		file.createNewFile();
		writer = new BufferedWriter(new FileWriter(file));
		BufferedReader reader1 = new BufferedReader(new FileReader(file2));
		BufferedReader reader2 = new BufferedReader(new FileReader(nerfile));
		String line1 = reader1.readLine();
		System.out.println(line1);
		String line2 = reader2.readLine();
		System.out.println(line2);
		int lineNum = 1;
		HashSet<String> finalwords = new HashSet<String>();
		while (line1 != null && !line1.isEmpty())
		{
			finalwords.add(line1);
			line1 = reader1.readLine();
		}
		while (line2 != null && !line2.isEmpty())
		{
			finalwords.add(line2);
			line2 = reader2.readLine();
		}
		reader1.close();
		reader2.close();
		Iterator<String> i = finalwords.iterator();
		while(i.hasNext()) {
			writer.write(i.next());
			writer.newLine();
		}

		writer.close();

		return file;
	}

	public static void updatedocuments(ArrayList<List<String>> wordsofdocuments, File file,int slidingwindowcount) {
		// TODO Auto-generated method stub

		for(List<String> documents: wordsofdocuments) {

			for (int i = 0; i < documents.size() - slidingwindowcount + 1; i++) {
				//String[] documentwords = new String[documents.size()];
				String[] documentwords = documents.toArray(new String[documents.size()]);
				String joint = join(documentwords, i, i+slidingwindowcount);
				try (Scanner scanner = new Scanner(file)) {
					while (scanner.hasNextLine()) {
						String line = scanner.nextLine();
						if(joint.equals(line))
						{
							documents.set(i, joint);
							for(int k=i+1;k < documents.size() && k< (i+ slidingwindowcount);k++) {
								documents.remove(k);
							}
						}
					}

					scanner.close();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			//    }

		}
		System.out.println(wordsofdocuments.get(0).size());

	}



}
