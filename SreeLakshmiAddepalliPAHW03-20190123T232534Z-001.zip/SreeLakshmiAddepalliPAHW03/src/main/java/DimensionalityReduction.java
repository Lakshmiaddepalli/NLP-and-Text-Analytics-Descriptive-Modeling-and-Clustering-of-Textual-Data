package main.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.stat.correlation.Covariance;

import cern.colt.matrix.DoubleMatrix2D;
import cern.colt.matrix.DoubleMatrix1D;
import cern.colt.matrix.doublealgo.Statistic;
import cern.colt.matrix.impl.DenseDoubleMatrix2D;
import cern.colt.matrix.impl.SparseDoubleMatrix2D;
import cern.colt.matrix.linalg.Algebra;
import cern.colt.matrix.linalg.EigenvalueDecomposition;
import hep.aida.bin.DynamicBin1D;


class Tuple<X,Y>{
	public final double x;
	public final double y;

	public Tuple(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}


}

public class DimensionalityReduction {


	public static HashMap<Integer, Tuple> principlecomponentanalysis(ArrayList<ArrayList<Double>> tfidfmatrix, ArrayList<String> total_unique_terms) throws IOException {

		double[][] fullmatrix = new double[tfidfmatrix.size()][];
		int k = 0;
		for(ArrayList<Double> document: tfidfmatrix) {
			double[] vectorval = new double[document.size()];
			for(int j =0; j< vectorval.length;j++) {
				vectorval[j] = document.get(j).doubleValue();
			}
			fullmatrix[k]= vectorval;
			k+=1;
		}
		printmatrix(fullmatrix,total_unique_terms);
		DoubleMatrix2D matrix = new DenseDoubleMatrix2D(fullmatrix);
		DoubleMatrix2D pm = pcaTransform(matrix);

		// print the first two dimensions of the transformed matrix - they capture most of the variance of the original data
		System.out.println(pm.viewPart(0, 0, pm.rows(), 2).toString());
		HashMap<Integer,Tuple> points = new HashMap<Integer,Tuple>();
		double[][] x = pm.toArray();

		System.out.println(x.length);
		System.out.println(x[0].length);

		for(int i =0;i <x.length;i++) {
			double xpoint = x[i][0];
			double ypoint = x[i][1];
			Tuple tuple = new Tuple(xpoint,ypoint);
			points.put(i+1,tuple);
		}

		return points;
	}

	/** Returns a matrix in the space of principal components, take the first n columns  */
	public static DoubleMatrix2D pcaTransform(DoubleMatrix2D matrix) {
		DoubleMatrix2D zScoresMatrix = toZScores(matrix);
		final DoubleMatrix2D covarianceMatrix = Statistic.covariance(zScoresMatrix);

		// compute eigenvalues and eigenvectors of the covariance matrix (flip needed since it is sorted by ascending).
		final EigenvalueDecomposition decomp = new EigenvalueDecomposition(covarianceMatrix);

		// Columns of Vs are eigenvectors = principal components = base of the new space; ordered by decreasing variance
		final DoubleMatrix2D Vs = decomp.getV().viewColumnFlip(); 

		// eigenvalues: ev(i) / sum(ev) is the percentage of variance captured by i-th column of Vs
		// final DoubleMatrix1D ev = decomp.getRealEigenvalues().viewFlip();

		// project the original matrix to the pca space
		return Algebra.DEFAULT.mult(zScoresMatrix, Vs);
	}

	public static DoubleMatrix2D toZScores(final DoubleMatrix2D matrix) {
		final DoubleMatrix2D zMatrix = new SparseDoubleMatrix2D(matrix.rows(), matrix.columns());
		for (int c = 0; c < matrix.columns(); c++) {
			final DoubleMatrix1D column = matrix.viewColumn(c);
			final DynamicBin1D bin = Statistic.bin(column);

			if (bin.standardDeviation() == 0) {   // use epsilon
				for (int r = 0; r < matrix.rows(); r++) {
					zMatrix.set(r, c, 0.0);
				}
			} else {
				for (int r = 0; r < matrix.rows(); r++) {
					double zScore = (column.get(r) - bin.mean()) / bin.standardDeviation();
					zMatrix.set(r, c, zScore);
				}
			}
		}

		return zMatrix;
	}


	/*	RealMatrix realMatrix = MatrixUtils.createRealMatrix(fullmatrix);
		//realMatrix =realMatrix.transpose();
		Covariance covariance = new Covariance(realMatrix);
		RealMatrix covarianceMatrix = covariance.getCovarianceMatrix();
		EigenDecomposition ed = new EigenDecomposition(covarianceMatrix);
		RealMatrix realMatrix1 = ed.getD();
		RealMatrix realMatrix2 = ed.getV();
		RealVector realMatrix3 = ed.getEigenvector(0);
		RealVector realMatrix4 = ed.getEigenvector(1);
		RealVector realMatrix5 = ed.getEigenvector(2);
		//	ed.
		System.out.println(); */
	//	}

	private static void printmatrix(double[][] fullmatrix, ArrayList<String> total_unique_terms) throws IOException {
		// TODO Auto-generated method stub
		BufferedWriter writer = null;
		File file = new File("src/resources/tfidfmatrix/tfidfmatrix.csv");
		file.createNewFile();
		writer = new BufferedWriter(new FileWriter(file));


		System.out.println(fullmatrix.length);
		System.out.println(fullmatrix[0].length);
		for(int i = 0;i <fullmatrix.length;i++) {
			for(int j = 0;j <fullmatrix[0].length;j++) {
				if(j!=0) {
					writer.write(",");
					System.out.print(",");
				}
				double val = fullmatrix[i][j];
				writer.write(String.valueOf(val));
				System.out.print(fullmatrix[i][j]);
			}
			System.out.println();
			writer.newLine();
		}
		writer.close();

	}
}