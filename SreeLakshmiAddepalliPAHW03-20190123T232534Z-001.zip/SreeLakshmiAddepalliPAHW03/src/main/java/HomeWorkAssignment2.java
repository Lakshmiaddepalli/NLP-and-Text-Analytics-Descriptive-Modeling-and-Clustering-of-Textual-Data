package main.java;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;

public class HomeWorkAssignment2 {

	public static int numberofdocuments = 0;

	public static void main(String[] args) throws IOException, ParseException{
		// TODO Auto-generated method stub

		readData datasourceloc = new readData();
		configfileread cfg = new configfileread();
		for(String document : datasourceloc.getlocationofdatasource()) {
			preprocess.preprocessing(document,cfg.getSliding_window_count());	
			numberofdocuments++;
		}
		
		File nerfile = namedentityrecognition.print_ner_tags(namedentityrecognition.nervalues,cfg.getThreshold_ner_tags());
		File file = ngram.printtofile(cfg.getThreshold_ngram_tags(),cfg.getSliding_window_count());
		// System.out.println(preprocess.wordsofdocuments.get(0).size());
		File finalfile = ngram.mergefile(file,nerfile);
		ngram.updatedocuments(preprocess.wordsofdocuments,finalfile,cfg.getSliding_window_count());
		for(List<String> documents: preprocess.wordsofdocuments) {
			System.out.println(documents.toString());
		}
		ArrayList<String> total_unique_terms = termdocumentmatrix.terms_in_documents(preprocess.wordsofdocuments);
		ArrayList<Map<String, Integer>> frequency_dic = termdocumentmatrix.terms_frequency(preprocess.wordsofdocuments);
		ArrayList<ArrayList<Integer>> matrix = termdocumentmatrix.term_document_frequency(total_unique_terms,frequency_dic);
		//System.out.println("Hi" + numberofdocuments);
		ArrayList<ArrayList<Double>> tfidfmatrix = termdocumentmatrix.tfidf(matrix,numberofdocuments);
		termdocumentmatrix.printtopkeywordsperdoc(tfidfmatrix,total_unique_terms,(numberofdocuments/readData.numberoffolders),cfg.getFrequency_of_topics_per_folder());
		kmeans.kmeansalgo(tfidfmatrix,cfg.getNumber_of_clusters(),cfg.getSimilarity(),cfg.getMax_iterations());
		ConfusionMatrix.generateconfusionmatrix(cfg.number_of_clusters);
		ConfusionMatrix.printconfusionmatrix(cfg.number_of_clusters);
		HashMap<Integer, Tuple> reduced_data= DimensionalityReduction.principlecomponentanalysis(tfidfmatrix,total_unique_terms);
		visualise.data(reduced_data);
	}

}
