package main.java;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class configfileread {

	public int sliding_window_count;
	public int threshold_ner_tags;
	public int threshold_ngram_tags;
	public int frequency_of_topics_per_folder;
	public int number_of_clusters;
	public int max_iterations;
	public String similarity;
	public boolean Lemmatisation;
	public int knearestneighbours;
	
	public configfileread() throws FileNotFoundException, IOException, ParseException {
		Object obj = new JSONParser().parse(new FileReader("src/resources/config.json")); 
		JSONObject jo = (JSONObject) obj; 

		sliding_window_count = (int)((long)jo.get("sliding_window_count"));
		threshold_ner_tags = (int)((long)jo.get("threshold_ner_tags"));
		threshold_ngram_tags = (int)((long)jo.get("threshold_ngram_tags"));
		frequency_of_topics_per_folder = (int)((long)jo.get("frequency_of_topics_per_folder"));
		number_of_clusters = (int)((long)jo.get("number_of_clusters"));
		max_iterations = (int)((long)jo.get("max_iterations"));
		similarity = (String) jo.get("similarity"); 
		Lemmatisation = (boolean) jo.get("Lemmatisation");
		knearestneighbours = (int)((long)jo.get("K-Nearest-Neighbours"));
	}
	public boolean isLemmatisation() {
		return Lemmatisation;
	}
	public void setLemmatisation(boolean lemmatisation) {
		Lemmatisation = lemmatisation;
	}
	public int getSliding_window_count() {
		return sliding_window_count;
	}
	public void setSliding_window_count(int sliding_window_count) {
		this.sliding_window_count = sliding_window_count;
	}
	public int getThreshold_ner_tags() {
		return threshold_ner_tags;
	}
	public void setThreshold_ner_tags(int threshold_ner_tags) {
		this.threshold_ner_tags = threshold_ner_tags;
	}
	public int getThreshold_ngram_tags() {
		return threshold_ngram_tags;
	}
	public void setThreshold_ngram_tags(int threshold_ngram_tags) {
		this.threshold_ngram_tags = threshold_ngram_tags;
	}
	public int getFrequency_of_topics_per_folder() {
		return frequency_of_topics_per_folder;
	}
	public void setFrequency_of_topics_per_folder(int frequency_of_topics_per_folder) {
		this.frequency_of_topics_per_folder = frequency_of_topics_per_folder;
	}
	public int getNumber_of_clusters() {
		return number_of_clusters;
	}
	public void setNumber_of_clusters(int number_of_clusters) {
		this.number_of_clusters = number_of_clusters;
	}
	public int getMax_iterations() {
		return max_iterations;
	}
	public void setMax_iterations(int max_iterations) {
		this.max_iterations = max_iterations;
	}
	public String getSimilarity() {
		return similarity;
	}
	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	public int getKnearestneighbours() {
		return knearestneighbours;
	}
	public void setKnearestneighbours(int knearestneighbours) {
		this.knearestneighbours = knearestneighbours;
	}




}
