package main.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.Map.Entry;

public class kmeans {

	static HashMap<String,ArrayList<Integer>> predictedclass = new HashMap<String,ArrayList<Integer>>();

	public static void kmeansalgo(ArrayList<ArrayList<Double>> tfidfmatrix,int k, String distance,int max_iterations) throws IOException {

		Random rand = new Random(); 
		final int[] centroids = new Random().ints(0,tfidfmatrix.size()).distinct().limit(k).toArray();
		int[] centroidkmeansplusplus = new int[k];
		//centroidkmeansplusplus[0] = rand.nextInt(tfidfmatrix.size());
		
		ArrayList<Double> initial =  tfidfmatrix.get(0);
	/*	int previous_counter = Integer.MAX_VALUE;
		double previousminval = Double.MAX_VALUE;
		ArrayList<Double> previous_initial = null;
		double minval = Double.MAX_VALUE; 
		for(int i =1;i<k;i++) {
			int counter=0;
			for(ArrayList<Double> document:tfidfmatrix) {
				double distanceval = simlaritydistance.computeCosineSimilarity(document,initial);
				if(distanceval < minval) {
					double previousdistanceval = simlaritydistance.computeCosineSimilarity(document,previous_initial);
					if(previousdistanceval < )
					previousminval = minval;
					minval = distanceval;
					if(previous_counter!= counter) {
					centroidkmeansplusplus[i] = counter;
					previous_counter= counter;
					}
					previous_initial = initial;
					initial = document;
				}
				counter++;
			}
		} */
		ArrayList<ArrayList<Double>> centroidvalues = new ArrayList<ArrayList<Double>>();


		for(int i =0;i<k;i++) {
			centroidvalues.add(tfidfmatrix.get(centroids[i]));
		}

		int iterations = 0;
		HashMap<Integer,ArrayList<HashMap<Integer,ArrayList<Double>>>> centroiddocumentmap = null;
		while(iterations <max_iterations) {
			centroiddocumentmap = new HashMap<Integer,ArrayList<HashMap<Integer,ArrayList<Double>>>>();
			int documentnumber = 0;
			int sizes = Integer.MAX_VALUE;
			for(ArrayList<Double> document: tfidfmatrix) {
				sizes = document.size();
				int index = Integer.MIN_VALUE;
				if(distance.equals("Cosine")) {
					double max =Integer.MIN_VALUE;
					for(int i =0;i<k;i++) {
						double cosineval = simlaritydistance.computeCosineSimilarity(document,centroidvalues.get(i));
						if(cosineval > max) {
							max = cosineval;
							index = i;
						}
					}
				}
				else {
					double min =Integer.MAX_VALUE;
					for(int i =0;i<k;i++) {
						double euclidianvalue = simlaritydistance.computeEuclidianSimilarity(document,centroidvalues.get(i));
						if(euclidianvalue < min) {
							min = euclidianvalue;
							index = i;
						}
					}
				}
				documentnumber++;
				if(centroiddocumentmap.containsKey(index+1)) {
					HashMap<Integer,ArrayList<Double>> temp1 = new HashMap<Integer,ArrayList<Double>>();
					temp1.put(documentnumber,document);
					centroiddocumentmap.get(index+1).add(temp1);
				}
				else {
					ArrayList<HashMap<Integer,ArrayList<Double>>> temp = new ArrayList<HashMap<Integer,ArrayList<Double>>>();
					HashMap<Integer,ArrayList<Double>> temp1 = new HashMap<Integer,ArrayList<Double>>();
					temp1.put(documentnumber,document);
					temp.add(temp1);
					centroiddocumentmap.put(index+1,temp);
				}

				//	System.out.println(centroiddocumentmap.toString());
			}



			for (Entry<Integer,ArrayList<HashMap<Integer,ArrayList<Double>>>>  entry1 : centroiddocumentmap.entrySet()) {
				int sum = 0;
				int indexval = entry1.getKey();
				ArrayList<Double> centroidaveragevalue = new ArrayList<Double>();
				//int sizes = entry1.getValue().get(0).get(0).size();
				for(int i =0;i<sizes;i++) {
					for(HashMap<Integer, ArrayList<Double>> entry2 : entry1.getValue()) {
						for(Entry<Integer,ArrayList<Double>> entry3: entry2.entrySet() ) {
							//	System.out.println(entry3.getValue().get(i).toString());
							sum += entry3.getValue().get(i);
							System.out.println(sum);
						}
					}
					System.out.println(entry1.getValue().size());
					Double average = (double) (sum/(entry1.getValue().size()));
					centroidaveragevalue.add(average);
				}
				centroidvalues.add(centroidaveragevalue);
			}
			iterations++;
		}
		for (Entry<Integer,ArrayList<HashMap<Integer,ArrayList<Double>>>>  entry1 : centroiddocumentmap.entrySet()) {
			ArrayList<Integer> documentnames = new ArrayList<Integer>();
			String finaldocumentclass = null;
			LinkedHashMap<String,Integer> documentnamescounter = new LinkedHashMap<String,Integer>();
			BufferedWriter writer = null;
			File file = new File("src/resources/clusters/cluster_" + entry1.getKey() + ".txt");
			file.createNewFile();
			writer = new BufferedWriter(new FileWriter(file));
			System.out.println("Class : " + entry1.getKey());
			System.out.println("-----------------------------------");
			System.out.println();
			for(HashMap<Integer, ArrayList<Double>> entry2 : entry1.getValue()) {
				for(Entry<Integer,ArrayList<Double>> entry3: entry2.entrySet() ) {
					writer.write("Document : " + entry3.getKey());
					writer.newLine();
					System.out.println("Document : " + entry3.getKey());
					String documentclass = classofdocument(entry3.getKey());
					if(documentnamescounter.containsKey(documentclass)) {
						documentnamescounter.put(documentclass,documentnamescounter.get(documentclass) + 1);
					}
					else {
						documentnamescounter.put(documentclass, 1);
					}

					documentnames.add(entry3.getKey());

					System.out.println();
				}

			}
			finaldocumentclass = FinalClass(documentnamescounter);
			for(Entry<String, ArrayList<Integer>> entryval : predictedclass.entrySet()) {
				if(entryval.getKey().contains(finaldocumentclass)) {
					System.out.println("Increase number of iterations, cant decide the Prediction classes yet");
					System.exit(1);
				}
			}
			predictedclass.put(finaldocumentclass, documentnames);
			writer.close();
		}
	}

	public static String classofdocument(Integer documentname) {
		// TODO Auto-generated method stub
		for(Entry<String, ArrayList<Integer>> entry1 : termdocumentmatrix.actualclass.entrySet()) {
			if(entry1.getValue().contains(documentname)) {
				return entry1.getKey();
			}
		}
		return null;
	}


	public static String FinalClass(LinkedHashMap<String, Integer> documentnamescounter) {
		Entry<String, Integer> maxEntry = null;
		for (Entry<String, Integer> entry : documentnamescounter.entrySet())
		{
			if (maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
			{
				maxEntry = entry;
			}
		}
		return maxEntry.getKey();
	}



}
