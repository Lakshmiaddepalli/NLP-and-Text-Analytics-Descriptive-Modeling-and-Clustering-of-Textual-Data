package main.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class termdocumentmatrix {

	static BufferedWriter writer = null;
	static File topicsfile = new File("src/resources/topicsoffolder/topics.txt");
	static Double maxvalue = Double.MIN_VALUE;
	static String clustername = null;
	static HashMap<String,ArrayList<Integer>> actualclass = new HashMap<String,ArrayList<Integer>>();
	
	public static ArrayList<String> terms_in_documents(ArrayList<List<String>> documents) {
		ArrayList<String> terms = new ArrayList<String>();
		for(List<String> document : documents) {
			for(String words: document) {
				if(!terms.contains(words)) {
					terms.add(words);
				}	
			}
		}
		System.out.println(terms.size());
		System.out.println(terms.toString());
		return terms;
	}

	public static ArrayList<Map<String, Integer>> terms_frequency(ArrayList<List<String>> wordsofdocuments) {
		// TODO Auto-generated method stub
		ArrayList<Map<String, Integer>> document_term_frequency = new ArrayList<Map<String, Integer>>();
		for(List<String> document : wordsofdocuments) {
			document_term_frequency.add(counter(document));
		}

		for(Map<String, Integer> dic: document_term_frequency) {
			System.out.println("Document Start");
			for (Entry<String, Integer> entry : dic.entrySet()) {
				System.out.println("Term: " + entry.getKey() + " Frequency:" + entry.getValue());
			}
			System.out.println("Document End");
		}

		return document_term_frequency;
	}

	public static Map<String, Integer> counter(List<String> document) {
		// TODO Auto-generated method stub
		Map<String, Integer> dictionary = new HashMap<String, Integer>();
		for(String s:document) {
			if (dictionary.containsKey(s)) {
				dictionary.put(s, dictionary.get(s) + 1);
			}else {
				dictionary.put(s,1);
			}
		}

		return dictionary;
	}

	public static ArrayList<ArrayList<Integer>> term_document_frequency(ArrayList<String> terms_in_documents,
			ArrayList<Map<String, Integer>> terms_frequency) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<Integer>> termdocumentfrequency = new ArrayList<ArrayList<Integer>>();
		for(Map<String, Integer> count :terms_frequency) {
			ArrayList<Integer> term_count_in_documents = new ArrayList<Integer>();
			for(String term : terms_in_documents) {
				Boolean set = false;
				for (Entry<String, Integer> entry : count.entrySet()) {
					if(term.equals(entry.getKey())) {
						term_count_in_documents.add(entry.getValue());
						set = true;
					}
				}
				if(!set){
					term_count_in_documents.add(0);
				}
			}
			termdocumentfrequency.add(term_count_in_documents);
		}
		return termdocumentfrequency;
	}

	public static ArrayList<ArrayList<Double>> tfidf(ArrayList<ArrayList<Integer>> matrix, int numberofdocuments) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<Double>> tfidfmatrix = new ArrayList<ArrayList<Double>>();
		for(ArrayList<Integer> document : matrix) {
			ArrayList<Double> tfidf = new ArrayList<Double>();
			int totalterms = 0;
			int counter = -1;
			for(Integer value: document) {
				totalterms += value;
			}
			for(Integer value: document) {
				counter++;
				double value1 =  ((double)value/(double)totalterms)*(double)(Math.log(numberofdocuments/(check(counter,matrix)))) ;
				tfidf.add(value1);
			}
			tfidfmatrix.add(tfidf);
		}
		return tfidfmatrix;
	}

	private static int check(Integer counter,ArrayList<ArrayList<Integer>> matrix) {
		// TODO Auto-generated method stub
		int documents_with_term = 0;
		for(ArrayList<Integer> document: matrix) {
			if(document.get(counter)!=0) {
				documents_with_term++;
			}
			else {
				documents_with_term = 1;
			}
		}
		return documents_with_term;

	}

	public static void printtopkeywordsperdoc(ArrayList<ArrayList<Double>> tfidfmatrix, ArrayList<String> total_unique_terms,int numberofdocuments,int topvalues) throws IOException {
		int i = 0;
		
		topicsfile.createNewFile();
		writer = new BufferedWriter(new FileWriter(topicsfile));
		int sizeofdocument = tfidfmatrix.get(0).size();
		ArrayList<Integer> documentnumbers = null;
		while(i< tfidfmatrix.size()) {
			maxvalue = Double.MIN_VALUE;
			clustername = null;
			documentnumbers = new ArrayList<Integer>();
			ArrayList<Double> doc = new ArrayList<Double>();
			for(int j = 0;j < sizeofdocument;j++)	{
				double sum = 0;
				for(int k = i;k<i+numberofdocuments;k++) {
					sum += tfidfmatrix.get(k).get(j);
				}
				doc.add(sum);
				
			}
			
			for(int k = i;k<i+numberofdocuments;k++) {
				documentnumbers.add(k+1);
			}
			Map<String,Double> map = new LinkedHashMap<String,Double>();  
			for (int a=0; a<total_unique_terms.size(); a++) {
				map.put(total_unique_terms.get(a), doc.get(a));    
			}

			
			
			int val = (i/numberofdocuments)+1;

			writer.newLine();
			writer.write("Folder: " + val );
			writer.newLine();
			writer.newLine();
			System.out.println("Folder: " + val );
			map.entrySet()
			.stream()
			.sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
			.limit(topvalues)
			.collect(Collectors.toMap(
					Map.Entry::getKey,
					Map.Entry::getValue,
					(e1, e2) -> e1,
					LinkedHashMap::new
					)).forEach((s, integer) -> {
						if(integer > maxvalue) {
							maxvalue = integer;
							clustername = s;
						}
						System.out.println(String.format("%s : %s", s, integer));
						try {
							writer.write(s);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							writer.newLine();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					});
			System.out.println();
			i = i+numberofdocuments;
			actualclass.put(clustername,documentnumbers);
		}

		

		writer.close();
	}

}
