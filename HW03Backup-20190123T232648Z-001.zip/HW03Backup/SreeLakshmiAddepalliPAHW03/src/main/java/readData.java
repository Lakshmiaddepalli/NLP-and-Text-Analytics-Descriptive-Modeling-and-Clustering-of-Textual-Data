package main.java;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class readData {
	ArrayList<String> documents = new ArrayList<String>();
	public static int numberoffolders = -1;

	public void listFilesAndFilesSubDirectories(String directoryName) throws IOException{

		File directory = new File(directoryName);
		File[] fList = directory.listFiles();
		for (File file : fList){
			if (file.isFile() && Pattern.matches(".*.txt", file.getName())){
				System.out.println(file.getName());
				documents.add(file.getPath());
			} else if (file.isDirectory()){
				numberoffolders++;
				listFilesAndFilesSubDirectories(file.getAbsolutePath());
			}
		}
	}


	public  ArrayList<String> getlocationofdatasource() {
		ClassLoader classLoader = readData.class.getClassLoader();
		File file = new File(classLoader.getResource("resources/data_location.txt").getFile());
		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				listFilesAndFilesSubDirectories("src/resources/" + line);
			}

			scanner.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return documents;
	}



}
