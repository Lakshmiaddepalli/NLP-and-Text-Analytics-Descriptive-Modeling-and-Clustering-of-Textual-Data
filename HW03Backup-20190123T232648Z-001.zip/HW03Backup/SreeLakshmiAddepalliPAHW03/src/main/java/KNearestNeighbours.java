package main.java;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.io.Charsets;

import edu.stanford.nlp.io.IOUtils;

public class KNearestNeighbours {

	static ArrayList<String> testingdocuments = new ArrayList<String>();
	static HashMap<String,ArrayList<Integer>> actuallassfortesting = new HashMap<String,ArrayList<Integer>>();
	static HashMap<String,ArrayList<Integer>> predictedclassfortesting = new HashMap<String,ArrayList<Integer>>();

	public static void readtestfiles(String directorypath) {

		File directory = new File(directorypath);
		File[] fList = directory.listFiles();
		for (File file : fList){
			if (file.isFile() && Pattern.matches(".*.txt", file.getName())){
				System.out.println(file.getName());
				testingdocuments.add(file.getPath());
			}
		}

	}

	public static void knn(ArrayList<ArrayList<Double>> tfidftestingmatrix,String distance,ArrayList<ArrayList<Double>> tfidfmatrix,int k) throws IOException {

		TreeMap<Double,Integer> values = null;
		BufferedWriter writer = null;
		File file = new File("src/resources/testsetdetails/testsetdetails.txt");
		file.createNewFile();

		writer = new BufferedWriter(new FileWriter(file));
		int counter1 = 0;

		for(ArrayList<Double> testdocument: tfidftestingmatrix){
			counter1 += 1;
			if(distance.equals("Cosine")) {
				values = new TreeMap<Double,Integer>(Collections.reverseOrder());}
			else {
				values = new TreeMap<Double,Integer>();
			}
			int counter = 0;

			for(ArrayList<Double> traindocument: tfidfmatrix){
				if(distance.equals("Cosine")) {
					double cosinevalue = simlaritydistance.computeCosineSimilarity(testdocument,traindocument);
					values.put(cosinevalue,counter + 1);
				}else {
					double euclidianvalue = simlaritydistance.computeEuclidianSimilarity(testdocument,traindocument);
					values.put(euclidianvalue,counter + 1);
				}
				counter++;
			}

			HashMap<String,Integer> dictionary = new HashMap<String,Integer>();
			int nearestneighbours = k;
			for (Entry<Double,Integer>  entry1 : values.entrySet()) {
				if(nearestneighbours > 0) {
					String s = kmeans.classofdocument(entry1.getValue());
					if (dictionary.containsKey(s)) {
						dictionary.put(s, dictionary.get(s) + 1);
					}else {
						dictionary.put(s,1);
					}
				}
				nearestneighbours--;

			}

			HashMap<String, Integer> dictionarysorted = dictionary.entrySet().stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder())).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue,(e1, e2) -> e1,LinkedHashMap::new));	 
			writer.write("Unknown0" + counter1 + ".txt");
			writer.newLine();
			Map.Entry<String, Integer> entry = dictionarysorted.entrySet().iterator().next();
			String val = entry.getKey();
			writer.write(val);
			writer.newLine();
			if(predictedclassfortesting.containsKey(val)) {
				ArrayList<Integer> x = predictedclassfortesting.get(val);
				x.add(counter1);
			}
			else {
				ArrayList<Integer> x = new ArrayList<Integer>();
				x.add(counter1);
				predictedclassfortesting.put(val,x);
			}
		}
		writer.close();

	}

	public static void fuzzyknn(ArrayList<ArrayList<Double>> tfidftestingmatrix,String distance,ArrayList<ArrayList<Double>> tfidfmatrix,int k) throws IOException {

		TreeMap<Double,Integer> values = null;
		BufferedWriter writer = null;
		File file = new File("src/resources/testsetdetails/fuzzyknntestsetdetails.txt");
		file.createNewFile();

		writer = new BufferedWriter(new FileWriter(file));
		int counter1 = 0;

		for(ArrayList<Double> testdocument: tfidftestingmatrix){
			counter1 += 1;
			if(distance.equals("Cosine")) {
				values = new TreeMap<Double,Integer>(Collections.reverseOrder());}
			else {
				values = new TreeMap<Double,Integer>();
			}
			int counter = 0;

			for(ArrayList<Double> traindocument: tfidfmatrix){
				if(distance.equals("Cosine")) {
					double cosinevalue = simlaritydistance.computeCosineSimilarity(testdocument,traindocument);
					values.put(cosinevalue,counter + 1);
				}else {
					double euclidianvalue = simlaritydistance.computeEuclidianSimilarity(testdocument,traindocument);
					values.put(euclidianvalue,counter + 1);
				}
				counter++;
			}

			HashMap<String,Integer> dictionary = new HashMap<String,Integer>();
			int nearestneighbours = k;
			for (Entry<Double,Integer>  entry1 : values.entrySet()) {
				if(nearestneighbours > 0) {
					String s = kmeans.classofdocument(entry1.getValue());
					if (dictionary.containsKey(s)) {
						dictionary.put(s, dictionary.get(s) + 1);
					}else {
						dictionary.put(s,1);
					}
				}
				nearestneighbours--;

			}

			HashMap<String, Integer> dictionarysorted = dictionary.entrySet().stream().sorted(Map.Entry.comparingByValue(Collections.reverseOrder())).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue,(e1, e2) -> e1,LinkedHashMap::new));	 
			writer.write("Unknown0" + counter1 + ".txt");
			writer.newLine();
			for (Entry<String,Integer>  entry1 : dictionarysorted.entrySet()) {
				String val = entry1.getKey();
				Double percent = entry1.getValue()/((double) k)*((double)100);
				String  ans = percent + "%  of " + val;
				writer.write(ans);
				writer.newLine();
			}


		}
		writer.close();
	}

	public static void actualclass(ArrayList<ArrayList<Double>> tfidftestingmatrix,
			ArrayList<String> total_unique_terms) throws IOException {
		// TODO Auto-generated method stub
		int documentcounter = 0;
		for(ArrayList<Double> row:tfidftestingmatrix) {
			documentcounter++;
			int indexval = (int)(row.indexOf(Collections.max(row)));
			String actualclassval = total_unique_terms.get(indexval);
			String actualclassafterlookup = checkclass(actualclassval);
			if(actuallassfortesting.containsKey(actualclassafterlookup)) {
				ArrayList<Integer> x = actuallassfortesting.get(actualclassafterlookup);
				x.add(documentcounter);
			}
			else {
				ArrayList<Integer> x = new ArrayList<Integer>();
				x.add(documentcounter);
				actuallassfortesting.put(actualclassafterlookup,x);
			}

		}

	}


	public static String checkclass(String word) throws IOException {
		// TODO Auto-generated method stub
		//KNearestNeighbours knnval = new KNearestNeighbours();
		//List<String> y = knnval.getResourceFiles("src/resources/testdictionary/");
		//ClassLoader classLoader = readData.class.getClassLoader();
		//classLoader.get("src/resources/testsetdictionary/");
		//	File file = new File(classLoader.getResource(y.get(0)).getFile());
		for (File f : getResourceFolderFiles("resources/testdictionary/")) {
			System.out.println(f);



			try (Scanner scanner = new Scanner(f)) {

				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					if(word.equals(line)) {
						return f.getName().toString();
					}
				}

				scanner.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

			
		}
		System.out.println("Class not present for current classes. please update the dictionary");
		System.exit(1);
		return "Class not present for current classes. please update the dictionary";
	}

	private static File[] getResourceFolderFiles (String folder) {
		//ClassLoader loader = Thread.currentThread().getContextClassLoader();
		ClassLoader classLoader = readData.class.getClassLoader();
		URL url = classLoader.getResource(folder);
		String path = url.getPath();
		return new File(path).listFiles();
	}


}
