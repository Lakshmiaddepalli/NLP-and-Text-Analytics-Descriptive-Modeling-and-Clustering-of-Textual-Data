package main.java;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class ConfusionMatrix {


	static TreeMap<String, TreeMap<String, Integer>> ConfusionMatrix = new TreeMap<String,TreeMap<String,Integer>>();

	public static void generateconfusionmatrix(int k) {

		for(Entry<String, ArrayList<Integer>> entry1: termdocumentmatrix.actualclass.entrySet()) {
			for(Entry<String, ArrayList<Integer>> entry2: kmeans.predictedclass.entrySet()) {

				TreeMap<String,Integer> mapping = new TreeMap<String,Integer>();
				addkeys(mapping);
				if(entry1.getKey().equals(entry2.getKey())) {
					ArrayList<Integer> actual = entry1.getValue();
					ArrayList<Integer> predicted = entry2.getValue();
					ArrayList<Integer> common = new ArrayList<Integer>(actual);
					ArrayList<Integer> notcommon = new ArrayList<Integer>(predicted);
					common.retainAll(predicted);
					notcommon.removeAll(actual);
					for(int e:notcommon) {
						String documentclass =	kmeans.classofdocument(e);
						mapping.put(documentclass,mapping.get(documentclass) + 1);
					}
					mapping.put(entry1.getKey(),common.size());
					ConfusionMatrix.put(entry1.getKey(),mapping);
				}

			}

		}
	}

	public static void addkeys(Map<String, Integer> mapping) {
		for(String key:termdocumentmatrix.actualclass.keySet()) {
			mapping.put(key, 0);
		}
	}

	public static void printconfusionmatrix(int k) throws IOException {
		BufferedWriter writer = null;
		File file = new File("src/resources/confusionmatrixdetails/confusionmatrix.txt");
		file.createNewFile();
		writer = new BufferedWriter(new FileWriter(file));
		int[][] confusionmatrixdata = new int[k][k];
		double precision_sum = 0;
		double recall_sum = 0;
		double f1score_sum = 0;
		System.out.print("      ");
		writer.write("      ");
		for(String key:ConfusionMatrix.keySet()) {
			System.out.print("    ");
			writer.write("      ");
			System.out.print("Actual_" + key);
			writer.write("Actual_" + key);
			writer.write("      ");

		}
		System.out.println("");
		writer.newLine();

		TreeMap<String,Integer> predictionsum = new TreeMap<String,Integer>();
		System.out.println("--------------------------------------------------------");
		writer.write("--------------------------------------------------------");
		int i = 0;
		for(Entry<String, TreeMap<String, Integer>> entry1: ConfusionMatrix.entrySet()) {
			System.out.println();
			writer.newLine();
			System.out.print("Predicted_" + entry1.getKey() +"|" +  "     ");
			writer.write("Predicted_" + entry1.getKey() +"|" +  "     ");
			System.out.print("       ");
			writer.write("       ");
			int sum =0;
			int j = 0;
			for(Entry<String,Integer>entry2 :entry1.getValue().entrySet()) {
				confusionmatrixdata[i][j] = entry2.getValue();
				sum += entry2.getValue();
				j+=1;
				System.out.print(entry2.getValue().toString());
				writer.write(entry2.getValue().toString());
				System.out.print("       ");
				writer.write("       ");
			}
			System.out.println();
			writer.newLine();
			predictionsum.put(entry1.getKey(),sum);
			i +=1;
		}

		System.out.println();
		writer.newLine();
		int index = 0;
		for(Entry<String,Integer>entry :predictionsum.entrySet()) {
			System.out.println("Total Predicted documents for " + entry.getKey() +" =  " + entry.getValue());
			writer.write("Total Predicted documents for " + entry.getKey() +" =  " + entry.getValue());
			writer.newLine();
			double precision = (double)confusionmatrixdata[index][index]/(double)entry.getValue();
			precision_sum += precision; 
			System.out.println("Total Precison for " + entry.getKey() +" =  " + precision );
			writer.write("Total Precison for " + entry.getKey() +" =  " + precision );
			writer.newLine();
			double recall = (double)confusionmatrixdata[index][index]/(double)(HomeWorkAssignment2.numberofdocuments/readData.numberoffolders);
			recall_sum += recall; 
			System.out.println("Total Recall for " + entry.getKey() +" =  " + recall );
			writer.write("Total Recall for " + entry.getKey() +" =  " + recall);
			writer.newLine();
			double f1score = (double)(2*precision*recall)/(double)(precision + recall);
			f1score_sum += f1score; 
			System.out.println("Total F1 score for " + entry.getKey() +" =  " + f1score);
			writer.write("Total F1 score for " + entry.getKey() +" =  " + f1score);
			writer.newLine();
			System.out.println();
			writer.newLine();
			index += 1;
		}
		System.out.println();
		writer.newLine();
		System.out.println("Total Precision = " + (double)precision_sum/(double)k);
		writer.write("Total Precision = " + (double)precision_sum/(double)k);
		writer.newLine();
		System.out.println("Total Recall = " + (double)recall_sum/(double)k);
		writer.write("Total Recall = " + (double)recall_sum/(double)k);
		writer.newLine();
		System.out.println("Total F1score = " + (double)f1score_sum/(double)k);
		writer.write("Total F1score = " + (double)f1score_sum/(double)k);
		writer.newLine();
		writer.close();
	}
}
