package main.java;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import org.json.simple.parser.ParseException;

import edu.stanford.nlp.coref.CorefCoreAnnotations.CorefChainAnnotation;
import edu.stanford.nlp.coref.data.CorefChain;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.LemmaAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.NamedEntityTagAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations.CollapsedDependenciesAnnotation;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;
import edu.stanford.nlp.ie.crf.CRFClassifier;


public class preprocess {

	static ArrayList<List<String>> wordsofdocuments = new ArrayList<List<String>>();
	static ArrayList<List<String>> wordsoftestingdocuments = new ArrayList<List<String>>();

	public static void preprocessing(String documentpath, int slidingWindowCount) throws IOException, ParseException {
		String text = new String(Files.readAllBytes(Paths.get(documentpath)));
		namedentityrecognition.namedentityrecognition(text);
		text = text.replaceAll("[^A-Za-z0-9 .\r\n-]+", "").toLowerCase();
		configfileread cfg = new configfileread();
		wordsofdocuments.add(Lemmitisation(text,cfg.isLemmatisation()));
		ngram.counter(ngram.ngrams(slidingWindowCount, Lemmitisation(text,cfg.isLemmatisation())));
		System.out.println( wordsofdocuments.toString()); 
		System.out.println( "End of Processing" ); 
	}

	public static void preprocessingtestdocument(String documentpath, int slidingWindowCount) throws IOException, ParseException {
		String text = new String(Files.readAllBytes(Paths.get(documentpath)));
		//namedentityrecognition.namedentityrecognition(text);
		text = text.replaceAll("[^A-Za-z0-9 .\r\n-]+", "").toLowerCase();
		configfileread cfg = new configfileread();
		wordsoftestingdocuments.add(Lemmitisation(text,cfg.isLemmatisation()));
		ngram.counter(ngram.ngrams(slidingWindowCount, Lemmitisation(text,cfg.isLemmatisation())));
		System.out.println( wordsoftestingdocuments.toString()); 
		System.out.println( "End of Processing testing documents" ); 
	}
	
	public static ArrayList<String> Lemmitisation(String text,boolean flag) {
		ArrayList<String> lemmetisedwords = new ArrayList<String>();
		String lemma = null;
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, pos, lemma");
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
		Annotation document = new Annotation(text);
		pipeline.annotate(document);
		List <CoreMap> sentences = document.get(SentencesAnnotation.class);
		for (CoreMap sentence : sentences) { // traversing the words in the current sentence
			for (CoreLabel token : sentence.get(TokensAnnotation.class)) {// this is the text of the token
				String word = token.get(TextAnnotation.class);
				String namedentity = token.get(NamedEntityTagAnnotation.class);
				if(checknotstopword(word) && !word.equals(",") && !word.equals(".")) {
					if(flag) {
						lemma = token.get(LemmaAnnotation.class);
					}else {
						stemmer s = new stemmer(); 
						lemma = s.stem(word);
					}
					lemmetisedwords.add(lemma);
				}


			}
		}
		System.out.println("document");	
		System.out.println(lemmetisedwords.toString());
		return lemmetisedwords;

	}

	public static boolean checknotstopword(String word) {
		// TODO Auto-generated method stub
		ClassLoader classLoader = readData.class.getClassLoader();
		File file = new File(classLoader.getResource("resources/stopwords.txt").getFile());

		try (Scanner scanner = new Scanner(file)) {

			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if(word.equals(line)) {
					return false;
				}
			}

			scanner.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

		return true;
	}

}
