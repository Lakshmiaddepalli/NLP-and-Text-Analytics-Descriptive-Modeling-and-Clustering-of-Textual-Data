package main.java;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.json.simple.parser.ParseException;

public class HomeWorkAssignment2 {

	public static int numberofdocuments = 0;
	public static int numberoftestingdocuments = 0;

	public static void main(String[] args) throws IOException, ParseException{
		// TODO Auto-generated method stub

		readData datasourceloc = new readData();
		configfileread cfg = new configfileread();
		for(String document : datasourceloc.getlocationofdatasource()) {
			preprocess.preprocessing(document,cfg.getSliding_window_count());	
			numberofdocuments++;
		}

		File nerfile = namedentityrecognition.print_ner_tags(namedentityrecognition.nervalues,cfg.getThreshold_ner_tags());
		File file = ngram.printtofile(cfg.getThreshold_ngram_tags(),cfg.getSliding_window_count());
		File finalfile = ngram.mergefile(file,nerfile);
		ngram.updatedocuments(preprocess.wordsofdocuments,finalfile,cfg.getSliding_window_count());
		for(List<String> documents: preprocess.wordsofdocuments) {
			System.out.println(documents.toString());
		}
		ArrayList<String> total_unique_terms = termdocumentmatrix.terms_in_documents(preprocess.wordsofdocuments);
		ArrayList<Map<String, Integer>> frequency_dic = termdocumentmatrix.terms_frequency(preprocess.wordsofdocuments);
		ArrayList<ArrayList<Integer>> matrix = termdocumentmatrix.term_document_frequency(total_unique_terms,frequency_dic);
		ArrayList<ArrayList<Double>> tfidfmatrix = termdocumentmatrix.tfidf(matrix,numberofdocuments);
		termdocumentmatrix.printtopkeywordsperdoc(tfidfmatrix,total_unique_terms,(numberofdocuments/readData.numberoffolders),cfg.getFrequency_of_topics_per_folder());
		kmeans.kmeansalgo(tfidfmatrix,cfg.getNumber_of_clusters(),cfg.getSimilarity(),cfg.getMax_iterations());
		ConfusionMatrix.generateconfusionmatrix(cfg.number_of_clusters);
		ConfusionMatrix.printconfusionmatrix(cfg.number_of_clusters);
		HashMap<Integer, Tuple> reduced_data= DimensionalityReduction.principlecomponentanalysis(tfidfmatrix,total_unique_terms);
		visualise.data(reduced_data);


		KNearestNeighbours.readtestfiles("src/resources/testingdata/");
		for(String testingdocument : KNearestNeighbours.testingdocuments) {
			preprocess.preprocessingtestdocument(testingdocument,cfg.getSliding_window_count());	
			numberoftestingdocuments++;
		}

		ngram.updatedocuments(preprocess.wordsoftestingdocuments,finalfile,cfg.getSliding_window_count());
		for(List<String> documents: preprocess.wordsoftestingdocuments) {
			System.out.println(documents.toString());
		}

		ArrayList<Map<String, Integer>> frequency_dic_of_testingdocument = termdocumentmatrix.terms_frequency(preprocess.wordsoftestingdocuments);
		ArrayList<ArrayList<Integer>> matrixoftestingdocuments = termdocumentmatrix.term_document_frequency(total_unique_terms,frequency_dic_of_testingdocument);
		ArrayList<ArrayList<Double>> tfidftestingmatrix = termdocumentmatrix.tfidf(matrixoftestingdocuments,numberoftestingdocuments);
		KNearestNeighbours.actualclass(tfidftestingmatrix,total_unique_terms);
		KNearestNeighbours.knn(tfidftestingmatrix,cfg.getSimilarity(),tfidfmatrix,cfg.getKnearestneighbours());
		KNearestNeighbours.fuzzyknn(tfidftestingmatrix,cfg.getSimilarity(),tfidfmatrix,cfg.getKnearestneighbours());
		TestingDataConfusionMatrix.generateconfusionmatrix(cfg.number_of_clusters);
		TestingDataConfusionMatrix.printconfusionmatrix(cfg.number_of_clusters);
	}

}
